
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Polygons extends JFrame
{
	private static final int NONE = 0, DRAW = 1, MOVE = 2;
	private JButton btnDraw, btnMove, btnDelete;
	private JTextField txtInfo;
	private JPanel panelButtons;
	private PolygonPanel panelDraw;
	
	public Polygons()
	{
		super("Polygons");
		
		btnDraw = new JButton("Draw Polygon");
		btnMove = new JButton("Move Polygon");
		btnDelete = new JButton("Delete Polygon");
		txtInfo = new JTextField();
		
		btnMove.setEnabled(false);
		btnDelete.setEnabled(false);
		txtInfo.setEnabled(false);
		
		panelButtons = new JPanel();
		panelButtons.setLayout(new GridLayout(2,2));
		
		panelButtons.add(btnDraw);
		panelButtons.add(btnMove);
		panelButtons.add(btnDelete);
		panelButtons.add(txtInfo);
		
		add(panelButtons, BorderLayout.SOUTH);
		
		panelDraw = new PolygonPanel();
		add(panelDraw, BorderLayout.CENTER);
		
		ButtonActions btnHandler = new ButtonActions();
		btnDraw.addActionListener(btnHandler);
		btnMove.addActionListener(btnHandler);
		btnDelete.addActionListener(btnHandler);
		
		setSize(600,600);
		setVisible(true);
	}
	
	//Runs at the start of the program.
	public static void main(String args[])
	{
		Polygons application = new Polygons();
		application.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	//Listens for the user to click a button.
	private class ButtonActions implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			//If the user clicked "Draw Polygon".
			if (e.getSource() == btnDraw)
			{
				panelDraw.setMode(DRAW);
				btnDraw.setEnabled(false);
				txtInfo.setText("Click to add a point. Double click to finish.");
			}
			//If the user clicked "Move Polygon".
			else if (e.getSource() == btnMove)
			{
				if (panelDraw.selindex >= 0)
				{
					panelDraw.setMode(MOVE);
					btnMove.setEnabled(false);
					btnDelete.setEnabled(false);
					btnDraw.setEnabled(false);
					txtInfo.setText("Click and drag the mouse to move the polygon.");
				}
			}
			//If the user clicked "Delete Polygon".
			else if (e.getSource() == btnDelete)
			{
				if (panelDraw.selindex >= 0)
				{
					panelDraw.removePolygon();
					panelDraw.selindex = -1;
					btnMove.setEnabled(false);
					btnDelete.setEnabled(false);
					btnDraw.setEnabled(true);
					txtInfo.setText("Deleted selected polygon.");
				}
			}
		}
	}
	
	//Panel where the user can draw.
	private class PolygonPanel extends JPanel
	{
		private Vector<Polygon> polygonList;
		private Vector<Color> colorList;
		private Polygon newPolygon;
		private int selindex;     //Currently selected polygon from polygonList.
		private int x1, y1;       //Location of mouse.
		private int mode;         //None, Draw, or Move.
		private boolean creating; //For drawing polygon.
		private int startx, starty, endx, endy; //Moving the polygon.
		private boolean moving;                    //Moving the polygon.
		
		public PolygonPanel()
		{
			polygonList = new Vector<Polygon>();
			colorList = new Vector<Color>();
			selindex = -1;
			setOpaque(true);
			
			//Listens for the user to click on the panel.
			addMouseListener
			(
					new MouseAdapter()
					{
						public void mouseClicked(MouseEvent e)
						{
							x1 = e.getX();
							y1 = e.getY();
							//If the user might be trying to select an existing polygon.
							


if (mode == Polygons.NONE)
							{
								selindex = getSelected(x1,y1,selindex);
								if (selindex >= 0)
								{
									btnMove.setEnabled(true);
									btnDelete.setEnabled(true);
									btnDraw.setEnabled(false);
								}
								else
								{
									btnMove.setEnabled(false);
									btnDelete.setEnabled(false);
									btnDraw.setEnabled(true);
								}
							}
							//If the user clicked the draw button.
							else if (mode == Polygons.DRAW)
							{
								//First click for the polygon.
								if (creating == false)
								{
									newPolygon = new Polygon();
									newPolygon.addPoint(x1, y1);
									addPolygon(newPolygon);
									creating = true;
								}
								//If the user clicked to add a point.
								else if (e.getClickCount() == 1)
								{
									newPolygon = polygonList.get(polygonList.size() - 1);
									newPolygon.addPoint(x1, y1);
									polygonList.set(polygonList.size() - 1, newPolygon);
								}
								//If the user double clicked to add the last point.
								else if (e.getClickCount() == 2)
								{
									creating = false;
									mode = Polygons.NONE;
									btnDraw.setEnabled(true);
									txtInfo.setText("Created new polygon.");
								}
							}
							repaint();
						}
						
						//When the user pressed the mouse during move mode.
						public void mousePressed(MouseEvent e)
						{
							x1 = e.getX();
							y1 = e.getY();
							if (mode == Polygons.MOVE)
							{
								//User must click in the polygon to begin moving.
								if (polygonList.elementAt(selindex).contains(x1,y1))
								{
									startx = x1;
									starty = y1;
									moving = true;
								}
							}
						}
						
						//When the user releases the mouse during move mode.
						public void mouseReleased(MouseEvent e)
						{
							if (mode == Polygons.MOVE)
							{
								//User must start moving in order to end move mode.
								if (moving == true)
								{
									moving = false;
									mode = Polygons.NONE;
									btnDraw.setEnabled(true);
									txtInfo.setText("Moved polygon.");
									colorList.setElementAt(Color.black, selindex);
									selindex = -1;
									repaint();
								}
							}
						}
					}
			);
			
			//Listens for the user to drag the mouse on the panel.
			addMouseMotionListener
			(
					new MouseMotionAdapter()
					{
						public void mouseDragged(MouseEvent e)
						{
							if (moving == true)
							{
								endx = e.getX();
								endy = e.getY();
								//If the user is moving a polygon.
								if (mode == Polygons.MOVE)
								{
									newPolygon = polygonList.elementAt(selindex);
									newPolygon.translate(endx-startx,endy-starty);
									repaint();
									startx = endx;
									starty = endy;
								}
							}
						}
					}
			);
			
		}
		
		//Obtains a polygon at the selected location if not in draw mode.
		private int getSelected(double x, double y, int cur)
		{
			//Sets the previously selected polygon to black.
			if (cur >= 0)
			{
				colorList.setElementAt(Color.black, cur);
			}
			//Checks all polygons after previously selected polygon.
			for (int i = cur + 1; i < polygonList.size(); i++)
			{
				if ((polygonList.elementAt(i)).contains(x,y))
				{
					colorList.setElementAt(Color.red, i);
					txtInfo.setText("Choose to move or delete the selected polygon.");
					return i;
				}
			}
			//Checks the rest of the polygons starting from the beginning.
			for (int i = 0; i <= cur; i++)
			{
				if ((polygonList.elementAt(i)).contains(x,y))
				{
					colorList.setElementAt(Color.red,i);
					txtInfo.setText("Choose to move or delete the selected polygon.");
					return i;
				}
			}
			btnDraw.setEnabled(true);
			txtInfo.setText("");
			return -1;
		}
		
		//Sets the mode for the panel.
		public void setMode(int n)
		{
			mode = n;
		}
		
		//Adds a polygon to the list.
		public void addPolygon(Polygon p)
		{
			polygonList.addElement(p);
			colorList.addElement(Color.black);
			repaint();
		}
		
		//Removes a polygon from the list.
		public void removePolygon()
		{
			polygonList.remove(selindex);
			colorList.remove(selindex);
			repaint();
		}
		
		//Draws all of the polygons in the list.
		public void paintComponent (Graphics g)
		{
			super.paintComponent(g);
			Graphics2D g2d = (Graphics2D) g;
			for (int i = 0; i < polygonList.size(); i++)
			{
				g2d.setColor(colorList.elementAt(i));
				g2d.draw(polygonList.elementAt(i));
			}
		}
	}
}
